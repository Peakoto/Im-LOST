import Home from "./Home.css"

function Home() {
  return <h1 style={{ color: "black" }}>HELLO TEST</h1>;
}

export default Home;