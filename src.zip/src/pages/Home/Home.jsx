import "./Home.css";

function Home() {
  return <h2 style={{ color: "black" }}>PLEASE JUST F APPEAR ALREADY</h2>;
}

export default Home;