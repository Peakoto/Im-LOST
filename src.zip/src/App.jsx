import { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// Import pages
import Home from "./pages/Home/Home.jsx";
import PostLost from "./pages/Post_lost/PostLost.jsx";
import PostFound from "./pages/Post_found/PostFound.jsx";
import Profile from "./pages/Profile/Profile.jsx";

const App = () => {
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/post-lost" element={<PostLost />} />
          <Route path="/post-found" element={<PostFound />} />
          <Route path="/profile" element={<Profile />} />

          <Route path="*" element={<Navigate to="/" />} />
        </Routes>

        <h2>hi</h2>
      </div>
    </Router>
  );
}

export default App;
